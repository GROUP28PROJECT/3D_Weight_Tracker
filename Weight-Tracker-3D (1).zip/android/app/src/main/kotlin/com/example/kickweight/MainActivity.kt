package com.example.kickweight

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
